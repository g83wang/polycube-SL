#!/bin/bash

set -e
set -x

"${BASH_SOURCE%/*}/test2_2_4.sh" XDP_SKB
