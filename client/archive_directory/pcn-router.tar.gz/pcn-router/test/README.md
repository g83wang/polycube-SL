ROOT FOLDER

--TESTx_y.sh		x=number of routers, y=number of host

--TESTx_ys.sh		x=number of routers, y=number of host, s=use of secondary addresses

BRIDGE FOLDER

-- TESTx_y_z.sh		x=number of routers, y=number of bridges, z= number of host
